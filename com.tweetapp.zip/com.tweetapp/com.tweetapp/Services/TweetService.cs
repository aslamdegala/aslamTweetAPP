﻿using com.tweetapp.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using com.tweetapp.Services;

namespace com.tweetapp.Services
{
    public class TweetService : ITweetService
    {
        private readonly IMongoCollection<Tweet> _tweet;
        public TweetService(IDBClient dBClient)

        {
            _tweet = dBClient.GetTweetCollection();
        }

        public List<Tweet> Get()
        {

            var tweet= _tweet.Find(tweet => true).ToList();
            tweet.Reverse();
            return tweet;
        }


        public Tweet AddTweet(string username, Tweet tweet)
        {
            tweet.TweetTime = DateTime.Now.ToString();
            tweet.UserName = username;
            int tweetno = Get().Count();
            tweet.TweetReply = new List<Reply>();
            tweet.TweetLikes = new List<Like>();
            tweet.TweetId = tweetno + 1;
            _tweet.InsertOne(tweet);
            return tweet;
        }

        public List<Tweet> GetTweetsofUser(string username)
        {
            var sampledata = _tweet.Find(u => u.UserName == username).ToList<Tweet>();
            sampledata.Reverse();
            if (sampledata != null)
            {
                return sampledata;
            }
            return null;
        }

        public bool UpdateTweet(string username, int id, Tweet tweet)
        {
            var sampleTweet = _tweet.Find(t => t.UserName == username && t.TweetId == id).FirstOrDefault();
            if (sampleTweet != null)
            {
                tweet.Id = sampleTweet.Id;
                tweet.TweetTime = DateTime.Now.ToString();

                tweet.UserName = username;
                tweet.TweetId = id;
                tweet.TweetReply = sampleTweet.TweetReply;
                tweet.TweetLikes = sampleTweet.TweetLikes;
                _tweet.ReplaceOne(t => t.UserName == username && t.TweetId == id, tweet);

                return true;
            }
            return false;

        }

        public bool deleteTweet(string username, int id)
        {
            var sampleTweet = _tweet.Find(t => t.UserName == username && t.TweetId == id).FirstOrDefault();
            if (sampleTweet != null)
            {

                _tweet.DeleteOne(t => t.UserName == username && t.TweetId == id);

                return true;
            }
            return false;

        }

        public int LikeTweet(string username, int id)
        {
            var sampleTweet = _tweet.Find(t => t.TweetId == id).FirstOrDefault();


            if (sampleTweet != null)
            {
                var _like = new Like()
                {
                    username = username

                };
                sampleTweet.TweetLikes.Add(_like);
                _tweet.ReplaceOne(t => t.TweetId == id, sampleTweet);
                return 1;

            }
            return 0;

        }
        public bool ReplyTweet(string username, int id, Reply reply)
        {
            var sampleTweet = _tweet.Find(t => t.TweetId == id).FirstOrDefault();
            if (sampleTweet != null)
            {
                reply.TweetReplyTime = DateTime.Now.ToString();

                reply.username = username;
                sampleTweet.TweetReply.Add(reply);
                _tweet.ReplaceOne(t => t.TweetId == id, sampleTweet);


                return true;
            }
            return false;

        }
    }
}