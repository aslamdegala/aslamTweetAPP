﻿using com.tweetapp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.tweetapp.Services
{
    public interface ITweetService
    {
        List<Tweet> Get();
        Tweet AddTweet(string username, Tweet tweet);
        List<Tweet> GetTweetsofUser(string username);
        bool UpdateTweet(string username, int id, Tweet tweet);
        bool deleteTweet(string username, int id);
        int LikeTweet(string username, int id);
        bool ReplyTweet(string username, int id, Reply reply);
    }
}