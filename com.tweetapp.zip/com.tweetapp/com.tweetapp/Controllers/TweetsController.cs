﻿using com.tweetapp.Models;
using com.tweetapp.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.tweetapp.Controllers
{
    [Route("api/v1.0/[controller]")]
    [ApiController]
    public class TweetsController : ControllerBase
    {
        private readonly IUserService _UserService;
        private readonly ITweetService _TweetService;
        public TweetsController(ITweetService TweetService, IUserService UserService)
        {
            _TweetService = TweetService;
            _UserService = UserService;
        }

        /// <summary>
        /// Here We are Registering the user
        /// I always takes  the Unique username and email 
        /// if you same username and email which exist it thorow error
        /// we dont have to pass the  id i will automatically created by the mongodb
        /// </summary>
        /// <param name="user">User Data</param>
        /// <returns>gives  msg user registeration </returns>
        [HttpPost]
        [Route("[action]")]
        public ActionResult<User> register([FromBody] User user)
        {
            var data = _UserService.Register(user);
            if (data == null)
            {
                return NotFound("Users with same Email and UserName are Exist");

            }
            else
            {
                return Ok("Acoount Created Successfully");
            }

        }

        /// <summary>
        /// it is used to log in if we give the coreect username and password
        /// it will make us log in and we will recive the user details
        /// </summary>
        /// <param name="username">username at the time registeration</param>
        /// <param name="password"> password at the registeration</param>
        /// <returns>the user details</returns>
        [Route("[action]")]
        [HttpGet]
        public IActionResult Login(string username, string password)
        {
            User data = _UserService.login(username, password);

            if (data != null)
            {
                return Ok(data);
            }
            return Unauthorized("Invalid Credentials");
        }

        /// <summary>
        /// we can update the password here
        /// </summary>
        /// <param name="username"> username must be exist </param>
        /// <param name="password">new password</param>
        /// <returns>updated message</returns>
        [HttpGet]
        [Route("{username}/[action]")]
        public IActionResult forgot(string username, string password)
        {

            if (!_UserService.UpdatePassword(username, password))
            {
                return NotFound("UserName does not exist");
            }


            return Ok("Password is Updated Successfully");
        }

        /// <summary>
        /// All tweets of users
        /// </summary>
        /// <returns>tweets</returns>
        [HttpGet]
        [Route("[action]")]
        public IActionResult AllTweet()
        {
            return Ok(_TweetService.Get());
        }


        /// <summary>
        /// return all the users
        /// </summary>
        /// <returns>users</returns>

        [HttpGet]
        [Route("users/[action]")]
        public IActionResult AllUser()
        {
            return Ok(_UserService.Get());
        }




        /// <summary>
        /// searching user
        /// </summary>
        /// <param name="username">username</param>
        /// <returns>user</returns>

        [Route("[action]/username")]
        [HttpGet]
        public IActionResult Search(string username)
        {
            var data = _UserService.searchuser(username);
            if (data == null)
            {
                return NotFound("User is Not Found");

            }
            else
            {
                return Ok(data);
            }

        }

        /// <summary>
        /// tweet of specific user
        /// </summary>
        /// <param name="username">user name</param>
        /// <returns> user</returns>
        [HttpGet]
        [Route("[action]")]
        public IActionResult Username(string username)
        {
            var data = _TweetService.GetTweetsofUser(username);
            if (data.Count == 0)
            {
                return NotFound("User Tweets not Found");
            }
            return Ok(data);
        }



        /// <summary>
        /// we post the tweet
        /// </summary>
        /// <param name="username">username</param>
        /// <param name="tweet">tweet details here we dont have to pass _id
        /// we have to the specific  tweetid
        /// </param>
        /// <returns> tweet msg</returns>
        [HttpPost]
        [Route("{username}/[action]")]
        public ActionResult<Tweet> Add(string username, [FromBody] Tweet tweet)
        {
            _TweetService.AddTweet(username, tweet);
            return Ok("Tweet Posted Successfully");

        }



        /// <summary>
        /// we can update the tweet here
        /// </summary>
        /// <param name="username">username</param>
        /// <param name="id"> tweetid</param>
        /// <param name="tweet"> update tweet</param>
        /// <returns>msg</returns>
        [HttpPut]
        [Route("{username}/[action]/{id}")]
        public IActionResult Update(string username, int id, Tweet tweet)
        {

            if (!_TweetService.UpdateTweet(username, id, tweet))
            {
                return NotFound("UserName or Tweet Id does not exist");
            }


            return Ok("Tweet is Updated Successfully");
        }
        /// <summary>
        /// we can delete the tweet here
        /// </summary>
        /// <param name="username">username</param>
        /// <param name="id">tweet id</param>
        /// <returns> meassage</returns>
        [HttpDelete]
        [Route("{username}/[action]/{id}")]
        public IActionResult Delete(string username, int id)
        {

            if (!_TweetService.deleteTweet(username, id))
            {
                return NotFound("UserName or Tweet Id does not exist");
            }


            return Ok("Tweet is Deleted Successfully");
        }
        /// <summary>
        /// we can the tweet
        /// </summary>
        /// <param name="username">username who is liking thw tweet</param>
        /// <param name="id"> tweet id</param>
        /// <returns>msg</returns>
        [HttpPut]
        [Route("{username}/[action]/{id}")]
        public IActionResult Like(string username, int id)
        {
            int flag = _TweetService.LikeTweet(username, id);
            if (flag == 0)
            {
                return NotFound("Tweet Id does not exist");
            }

            return Ok("Tweet is Liked Successfully");
        }
        /// <summary>
        /// we can give reply tweete
        /// </summary>
        /// <param name="username">username who  isreplying the tweet </param>
        /// <param name="id">tweet id</param>
        /// <param name="reply">replay msg</param>
        /// <returns>msg</returns>

        [HttpPost]
        [Route("{username}/[action]/{id}")]
        public IActionResult Reply(string username, int id, Reply reply)
        {

            if (!_TweetService.ReplyTweet(username, id, reply))
            {
                return NotFound("UserName or Tweet Id does not exist ");
            }


            return Ok("Tweet is Reply Done");
        }
    }
}