﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.tweetapp.Models
{
    public interface IDBClient
    {
        IMongoCollection<User> GetUserCollection();
        IMongoCollection<Tweet> GetTweetCollection();
    }
}