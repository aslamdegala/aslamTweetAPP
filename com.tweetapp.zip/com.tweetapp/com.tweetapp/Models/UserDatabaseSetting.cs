﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.tweetapp.Models
{
    public class UserDatabaseSetting
    {
        public string UserCollection { get; set; }
        public string TweetCollection { get; set; }
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }

    }
}