﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace com.tweetapp.Models
{
    public class Tweet
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [Required(ErrorMessage = "Tweet Description Requried")]
        [StringLength(144, ErrorMessage = "Tweet Description Cannot be longer than 144 character")]
        [BsonElement("TweetDesp")]
        public string TweetDesp { get; set; }

        [BsonElement("TweetTag")]
        [StringLength(50, ErrorMessage = "Tweet Tags Cannot be longer than 50 character")]
        public string TweetTag { get; set; }

        //[BsonElement("TweetReply")]
        //[StringLength(144, ErrorMessage = "Tweet Reply Cannot be longer than 144 character")]
        //public string TweetReply { get; set; }


        [BsonElement("TweetReply")]
        public List<Reply> TweetReply { get; set; }


        [BsonElement("TweetLike")]
        public List<Like> TweetLikes { get; set; }

        [BsonElement("TweetTime")]
        public string TweetTime { get; set; }

        [Required(ErrorMessage = "UserName Requried")]
        [BsonElement("UserName")]
        public string UserName { get; set; }


        [Required(ErrorMessage = "TweetId Requried")]
        [BsonElement("TweetId")]
        public int TweetId { get; set; }

    }
}