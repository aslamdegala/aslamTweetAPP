﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace com.tweetapp.Models
{
    public class DBClient : IDBClient
    {
        private readonly IMongoCollection<User> _user;
        private readonly IMongoCollection<Tweet> _tweet;

        /// <summary>
        /// connecting to the mongodb
        /// </summary>
        /// <param name="databasesetting"></param>
        public DBClient(IConfiguration config)
        {
            var client = new MongoClient(config.GetValue<string>("TweetDBSettings:ConnectionString"));
            var database = client.GetDatabase(config.GetValue<string>("TweetDBSettings:DatabaseName"));
            _user = database.GetCollection<User>(config.GetValue<string>("TweetDBSettings:UserCollection"));
            _tweet = database.GetCollection<Tweet>(config.GetValue<string>("TweetDBSettings:TweetCollection"));
        }

        public IMongoCollection<User> GetUserCollection()
        {
            return _user;
        }

        public IMongoCollection<Tweet> GetTweetCollection()
        {
            return _tweet;
        }
    }
}