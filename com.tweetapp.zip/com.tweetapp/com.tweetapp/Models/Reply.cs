﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace com.tweetapp.Models
{
    public class Reply
    {
        [StringLength(144, ErrorMessage = "Tweet Reply Cannot be longer than 144 character")]
        public string ReplyMsg { get; set; }

        [StringLength(144, ErrorMessage = "Tweet Reply Cannot be longer than 144 character")]
        public string TweetReplytag { get; set; }

        public string TweetReplyTime { get; set; }
        public string username { get; set; }


    }
}